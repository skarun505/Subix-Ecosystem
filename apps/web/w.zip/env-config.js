/**
 * Environment Config — Injected at build/deploy time
 * ===================================================
 * This file provides environment variables to vanilla JS apps.
 * ⚠️ This file is gitignored. Create it locally with your real keys.
 */
window.__SUBIX_ENV__ = {
    NEXT_PUBLIC_SUPABASE_URL: "https://xrlqmngxxtbjxrkliypa.supabase.co",
    NEXT_PUBLIC_SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhybHFtbmd4eHRianhya2xpeXBhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE3MzI3MTUsImV4cCI6MjA4NzMwODcxNX0.qUBlRGyY8u-gUOkAjGvgKRrK36uzMuVMZj9Qs2zODQc",
    NEXT_PUBLIC_APP_URL: "https://subix.in",
    NEXT_PUBLIC_ACCOUNTS_URL: "https://accounts.subix.in",
    NEXT_PUBLIC_LEADOS_URL: "https://leados.subix.in",
    NEXT_PUBLIC_HRMS_URL: "https://hrms.subix.in",
};
